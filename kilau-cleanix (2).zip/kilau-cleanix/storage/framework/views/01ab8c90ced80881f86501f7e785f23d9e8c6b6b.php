<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>
    <div class="section-title-01 honmob">
        <div class="bg_parallax image_02_parallax"><div><img src="<?php echo e(asset('images\slidebackg\bookinglist.JPG')); ?>" alt="Background"></div></div>
        <div class="opacy_bg_02">
            <div class="container">
                <h1>BOOKING</h1>
                <div class="crumbs">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li>/</li>
                        <li>BOOKING</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="content-central">
        <div class="content_info">
            <div class="paddings-mini">
                <div class="container">
                    <div class="row portfolioContainer">
                        <div class="col-md-12 profile1">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-md-6">
                                            ALL BOOKING
                                        </div>
                                        <div class="col-md-6">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success" roles="alert"><?php echo e(Session::get('message')); ?></div>
                                <?php endif; ?>
                                <table class="table table-striped">
                                    <thead>
                                         <tr>
                                            <th>#</th> 
                                            <th>ServiceID</th> 
                                            <th>UserID</th> 
                                            <th>Phone Number</th> 
                                            <th>Address ln 1</th>
                                            <th>Address ln 2</th>
                                            <th>City</th>
                                            <th>State</th>
                                            <th>Country</th>
                                            <th>Zipcode</th>
                                            <th>Time / Date</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($booking->id); ?></td>
                                            <td><?php echo e($booking->service_id); ?></td>
                                            <td><?php echo e($booking->user_id); ?></td>
                                            <td><?php echo e($booking->mobile); ?></td>
                                            <td><?php echo e($booking->line1); ?></td>
                                            <td><?php echo e($booking->line2); ?></td>
                                            <td><?php echo e($booking->city); ?></td>
                                            <td><?php echo e($booking->province); ?></td>
                                            <td><?php echo e($booking->country); ?></td>
                                            <td><?php echo e($booking->zipcode); ?></td>
                                            <td><?php echo e($booking->time); ?> / <?php echo e($booking->date); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.edit_booking',['booking_id'=>$booking->id])); ?>"><button class="btn btn-primary">Edit</button></a>
                                            </td>
                                            <td>
                                                <a href="#" onclick="confirm('Are you sure you want to delete this category?') || event.stopImmediatePropagation()" wire:click.prevent="deleteOrderHistory(<?php echo e($booking->id); ?>)" style="margin-left:10px;"><i class="fa fa-times fa-2x text-danger"></i></a> 
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table> 
                                <h5 style="color: grey">Detailed data can be referred through collected data in database</h5>
                                <?php echo e($bookings->links()); ?>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/livewire/admin/admin-view-order-history.blade.php ENDPATH**/ ?>