<div>
    <div><body style="background-color:#659DBD;"></div>
        <div class="container" style="padding: 30px 0">
            <div class="row">
                <form wire:submit.prevent="bookForm">
                <div class="panel panel-default">
                    <div class="panel panel-heading">
                        Confirm Booking Details
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>
                        
                            <div class="col-md-8">
                                <p><b>Name: </b><input type="text" class="form-control" wire:model="name" required/></p>
                                <p><b>Email: </b><?php echo e($email); ?></p>
                                <p><b>Phone: </b><input type="text" class="form-control" wire:model="mobile"required/></p>
                                <hr>
                                <p><b>Time: </b><input type="time" class="form-control" wire:model="time"required/></p>
                                <p><b>Date: </b><input type="date" class="form-control" wire:model="date"required/></p>
                                <p><b>Line1: </b><input type="text" class="form-control" wire:model="line1"required/></p>
                                <p><b>Line2: </b><input type="text" class="form-control" wire:model="line2"required/></p>
                                <p><b>City: </b><input type="text" class="form-control" wire:model="city"required/></p>
                                <p><b>State: </b><input type="text" class="form-control" wire:model="province"required/></p>
                                <p><b>Country: </b><input type="text" class="form-control" wire:model="country"required/></p>
                                <p><b>Zipcode: </b><input type="text" class="form-control" wire:model="zipcode"required/></p>
                            </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Payment Breakdown</div>
                    <div class="panel-body">
                        <table class="table">
                            <tr>
                                <td style="border-top: none;">Price</td>
                                <td style="border-top: none;"><span>RM</span> <?php echo e($service->price); ?></td>
                            </tr>
                            <tr>
                                <td>Quantity</td>
                                <td>1</td>
                            </tr>
                            <?php
                                $total = $service->price;
                            ?>
                            <?php if($service->discount): ?> 
                                <?php if($service->discount_type=='fixed'): ?>
                                <tr>
                                    <td>Discount</td>
                                    <td><?php echo e($service->discount); ?></td>
                                </tr>
                                <?php $total = $total-$service->discount; ?>                                           
                                
                                <?php elseif($service->discount_type=='percent'): ?>
                                <tr>
                                    <td>Discount</td>
                                    <td><?php echo e($service->discount); ?></td>
                                    <?php $total = $total-($total*$service->discount/100); ?>
                                </tr>
                                
                                <?php endif; ?>                                          
                                
                            <?php endif; ?>
                            <tr>
                                <td>Total</td>
                                <td><span>RM</span> <?php echo e($total); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="panel-footer">
                        
                        <button name="confirmbooking" type="submit" class="btn btn-info pull right">Proceed</button>
                        
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/livewire/customer/confirm-booking-component.blade.php ENDPATH**/ ?>