@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-body">
            <h1>Kilau Cleanix</h1>
        </div>
        
    </div>
    <div class="card">
    </div>
@endsection