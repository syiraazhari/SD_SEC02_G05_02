

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h1>Kilau Cleanix</h1>
        </div>
        
    </div>
    <div class="card">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/admin/index.blade.php ENDPATH**/ ?>