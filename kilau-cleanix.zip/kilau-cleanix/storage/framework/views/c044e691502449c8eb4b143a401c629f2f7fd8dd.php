<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Kilau Cleanix')); ?></title>

    <!-- Nucleo Icons -->
  <link href="../admin/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../admin/css/nucleo-svg.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">

    <!-- CSS Files -->
    <link href="../admin/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../admin/css/paper-dashboard.css" rel="stylesheet" />

    <!-- Styles -->
    <link href="<?php echo e(asset('admin/css/paper-dashboard.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/custom.css')); ?>" rel="stylesheet">

</head>
<body>
    <div class = "wrapper">
        <?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class = "main-panel">
            <?php echo $__env->make('layouts.inc.adminnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class = "content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->make('layouts.inc.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

<!-- Scripts -->
<script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/perfect-scrollbar.jquery.min.js')); ?>" defer></script>

    
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/layouts/admin.blade.php ENDPATH**/ ?>