

<?php $__env->startSection('content'); ?>
    <div class="container">
    <form enctype="multipart/form-data" action="<?php echo e(url('update-profile')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col">
            <div class="card">
                <div class="card-header">
                    Profile Info
                </div>

                <div class="card-body">
                        <div class="row justify-content-center">
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header">
                                        <?php echo e(__('Profile Picture')); ?>

                                    </div>

                                    <div class="card-body">
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->avatar): ?>
                                            <img 
                                                src="<?php echo e(asset('assets/uploads/avatar/'.$item->avatar)); ?>"
                                                alt="Profile Picture" 
                                                style="width: 300px; height: 300px; border-radius: 50%; margin-left:auto; margin-right:auto;">
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="card-footer">
                                    
                                        <label>Profile Image</label>
                                        <input type="file" name="avatar">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        User Information
                                    </div>

                                    <div class="card-body">
                                        <?php if(session('status')): ?>
                                            <div class="alert alert-success" role="alert">
                                                <?php echo e(session('status')); ?>

                                            </div>
                                        <?php endif; ?>
                                            <div class="col-md-6 mb-3">
                                                <label for="">Name :</label>
                                                <input type="text" value="<?php echo e($user->name); ?>" class="form-control" name="name">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="">Email :</label>
                                                <input type="text" value="<?php echo e($user->email); ?>" class="form-control" name="email">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="">Phone :</label>
                                                <input type="text" value="<?php echo e($user->profile->mobile); ?>" class="form-control" name="phone">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="">Address 1 :</label>
                                                <input type="text" value="<?php echo e($user->profile->line1); ?>" class="form-control" name="address1">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="">Address 2 :</label>
                                                <input type="text" value="<?php echo e($user->profile->line2); ?>" class="form-control" name="address2">
                                            </div>                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="card-footer col-md-12">
                        <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/frontend/profile/edit.blade.php ENDPATH**/ ?>