<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>
    <div class="section-title-01 honmob">

        <div class="bg_parallax image_02_parallax"><div><img src="<?php echo e(asset('images\sercatg.jpg')); ?>" alt="Background"></div></div>
        <div class="opacy_bg_02">
            <div class="container">
                <h1>Service Categories</h1>
                <div class="crumbs">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li>/</li>
                        <li>Service Categories</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="content-central">
        <div class="content_info">
            <div class="paddings-mini">
                <div class="container">
                    <div class="row portfolioContainer">
                        <div class="col-md-12 profile1">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-md-6">
                                            All Service Category
                                        </div>
                                        <div class="col-md-6">
                                            <a href ="<?php echo e(route('admin.add_service_category')); ?>" class="btn btn-info pull-right">Add New</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success" roles="alert"><?php echo e(Session::get('message')); ?></div>
                                <?php endif; ?>
                                <table class="table table-striped">
                                    <thead>
                                         <tr>
                                            <th>#</th> 
                                            <th>Image</th> 
                                            <th>Name</th> 
                                            <th>Slug</th> 
                                            <th>Featured</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                     <?php $__currentLoopData = $scategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                             <td><?php echo e($scategory->id); ?></td>
                                             <td><img src="<?php echo e(asset('images/categories')); ?>/<?php echo e($scategory->image); ?>" width="60"/></td>
                                             <td><?php echo e($scategory->name); ?></td>
                                             <td><?php echo e($scategory->slug); ?></td>
                                             <td>
                                            <?php if($scategory->featured): ?>
                                                Yes
                                            <?php else: ?>
                                                No                                                
                                            <?php endif; ?>
                                            <td>
                                                <a href="<?php echo e(route('admin.edit_service_category',['category_id'=>$scategory->id])); ?>"><button class="btn btn-primary">Edit</button></a>
                                            </td>
                                            <td>
                                                <a href="#" onclick="confirm('Are you sure you want to delete this category?') || event.stopImmediatePropagation()" wire:click.prevent="deleteServiceCategory(<?php echo e($scategory->id); ?>)" style="margin-left:10px;"><i class="fa fa-times fa-2x text-danger"></i></a> 
                                            </td>	
                                         </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                 </table>
                                 <?php echo e($scategories->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/livewire/admin/admin-service-category-component.blade.php ENDPATH**/ ?>