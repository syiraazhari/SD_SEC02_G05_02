<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Kilau Cleanix')); ?></title>

    <!-- Nucleo Icons -->
  <link href="../admin/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../admin/css/nucleo-svg.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="../Frontend/css/mbr-additional.css"><link rel="stylesheet" href="../Frontend/css/mbr-additional.css" type="text/css">


    <!-- CSS Files -->
    <link href="../admin/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../admin/css/paper-dashboard.css" rel="stylesheet" />
    <link href="../admin/css/style.css" rel="stylesheet" />

    <link rel="stylesheet" href="../Frontend/css/web/mobirise2.css">
    <link rel="stylesheet" href="../Frontend/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Frontend/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="../Frontend/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="../Frontend/css/dropdown/style.css">
    <link rel="stylesheet" href="../Frontend/css/socicon/styles.css">
    <link rel="stylesheet" href="../Frontend/css/theme/style.css">
    <link rel="stylesheet" href="../Frontend/css/parallax/jarallax.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('admin/css/paper-dashboard.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/custom.css')); ?>" rel="stylesheet">

</head>
<body>
    <?php echo $__env->make('layouts.inc.frontnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class = "content">
      <?php echo $__env->make('layouts.inc.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>


<!-- Scripts -->
<script src="<?php echo e(asset('Frontend/css/theme/scripts.js')); ?>" defer></script>
<script src="<?php echo e(asset('Frontend/css/dropdown/navbar-dropdown.js')); ?>" defer></script>
<script src="<?php echo e(asset('Frontend/css/parallax/jarallax.js')); ?>" defer></script>
<script src="<?php echo e(asset('Frontend/css/smoothscroll/smooth-scroll.js')); ?>" defer></script>
<script src="<?php echo e(asset('Frontend/css/embla/embla.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('Frontend/css/embla/script.js')); ?>" defer></script>

<script src="<?php echo e(asset('admin/js/script.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('admin/js/perfect-scrollbar.jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>" defer></script>

    
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/layouts/front.blade.php ENDPATH**/ ?>