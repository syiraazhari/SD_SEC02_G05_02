<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>
    <div class="section-title-01 honmob">
        <div class="bg_parallax image_02_parallax"><div><img src="<?php echo e(asset('images\slidebackg\pic7.jpg')); ?>" alt="Background"></div></div>
        <div class="opacy_bg_02">
            <div class="container">
                <h1>Contacts</h1>
                <div class="crumbs">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li>/</li>
                        <li>Contacts</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="content-central">
        <div class="content_info">
            <div class="paddings-mini">
                <div class="container">
                    <div class="row portfolioContainer">
                        <div class="col-md-12 profile1">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-md-6">
                                            All Contacts
                                        </div>
                                        <div class="col-md-6">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success" roles="alert"><?php echo e(Session::get('message')); ?></div>
                                <?php endif; ?>
                                <table class="table table-striped">
                                    <thead>
                                         <tr>
                                            <th>#</th> 
                                            <th>Name</th> 
                                            <th>Email</th> 
                                            <th>Phone</th> 
                                            <th>Message</th>
                                            <th>Created At</th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($contact->id); ?></td>
                                            <td><?php echo e($contact->name); ?></td>
                                            <td><?php echo e($contact->email); ?></td>
                                            <td><?php echo e($contact->phone); ?></td>
                                            <td><?php echo e($contact->message); ?></td>
                                            <td><?php echo e($contact->created_at); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table> 
                                <?php echo e($contacts->links()); ?>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/livewire/admin/admin-contact-component.blade.php ENDPATH**/ ?>