

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
        <h1>Service Page</h1>
        <hr>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td>
                            <img src = "<?php echo e(asset('assets/uploads/service/'.$item->image)); ?>" class="service-image" alt="Image here">
                        </td>
                        <td>
                        <a href="<?php echo e(url('edit-serv/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
                        <a href="<?php echo e(url('delete-service/'.$item->id)); ?>" class="btn btn-danger">Delete</button>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/admin/service/index.blade.php ENDPATH**/ ?>