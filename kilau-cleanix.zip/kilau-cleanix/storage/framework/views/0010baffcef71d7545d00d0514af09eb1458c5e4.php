<div class="mbr-overlay"></div>
<div class="position-relative">
    <div class="mbr-section-head">
        <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
            <strong>Services</strong></h4>
        
    </div>
    <div class="embla mt-4" data-skip-snaps="true" data-align="center" data-contain-scroll="trimSnaps" data-auto-play-interval="5" data-draggable="true">
        <div class="embla__viewport container-fluid">
            <div class="embla__container">
                <div class="embla__slide slider-image item" style="margin-left: 1rem; margin-right: 1rem;">
                    <div class="slide-content">
                        <div class="item-img">
                            <div class="item-wrapper">
                                <img src="assets/images/about-us1.jpg" alt="Mobirise Website Builder" title="">
                            </div>
                        </div>
                        <div class="item-content">
                            <h5 class="item-title mbr-fonts-style display-5"><strong>About Us</strong></h5>
                            
                            <p class="mbr-text mbr-fonts-style mt-3 display-7">We're a professional cleaning service working in Kuala Lumpur, and we have over 100 professional cleaners ready to serve you.</p>
                        </div>
                        <div class="mbr-section-btn item-footer mt-2"><a href="" class="btn item-btn btn-black display-7" target="_blank">View Details &gt;</a></div>
                    </div>
                </div>
                <div class="embla__slide slider-image item" style="margin-left: 1rem; margin-right: 1rem;">
                    <div class="slide-content">
                        <div class="item-img">
                            <div class="item-wrapper">
                                <img src="assets/images/service1-2.jpg" alt="Mobirise Website Builder" title="">
                            </div>
                        </div>
                        <div class="item-content">
                            <h5 class="item-title mbr-fonts-style display-5"><strong>Services</strong></h5>
                            
                            <p class="mbr-text mbr-fonts-style mt-3 display-7">This is the service that we provide for our beloved users.Let us clean up your home while you enjoy living in the moment.</p>
                        </div>
                        <div class="mbr-section-btn item-footer mt-2"><a href="" class="btn item-btn btn-black display-7" target="_blank">View Details &gt;</a></div>
                    </div>
                </div>
                <div class="embla__slide slider-image item" style="margin-left: 1rem; margin-right: 1rem;">
                    <div class="slide-content">
                        <div class="item-img">
                            <div class="item-wrapper">
                                <img src="assets/images/promo.jpg" alt="Mobirise Website Builder" title="">
                            </div>
                        </div>
                        <div class="item-content">
                            <h5 class="item-title mbr-fonts-style display-5"><strong>Promotions</strong></h5>
                            
                            <p class="mbr-text mbr-fonts-style mt-3 display-7">Promotions that Kilau Cleanix offers for our lovely users<br></p>
                        </div>
                        <div class="mbr-section-btn item-footer mt-2"><a href="" class="btn item-btn btn-black display-7" target="_blank">View Details &gt;</a></div>
                    </div>
                </div>
                <div class="embla__slide slider-image item" style="margin-left: 1rem; margin-right: 1rem;">
                    <div class="slide-content">
                        <div class="item-img">
                            <div class="item-wrapper">
                                <img src="assets/images/tips.jpg" alt="Mobirise Website Builder" title="">
                            </div>
                        </div>
                        <div class="item-content">
                            <h5 class="item-title mbr-fonts-style display-5"><strong>Tips And Resources</strong></h5>
                            
                            <p class="mbr-text mbr-fonts-style mt-3 display-7">Tips from the pros and resources for users' references<br></p>
                        </div>
                        <div class="mbr-section-btn item-footer mt-2"><a href="" class="btn item-btn btn-black display-7" target="_blank">View Details &gt;</a></div>
                    </div>
                </div>
            </div>
        </div>
        <button class="embla__button embla__button--prev">
            <span class="mobi-mbri mobi-mbri-arrow-prev mbr-iconfont" aria-hidden="true"></span>
            <span class="sr-only visually-hidden visually-hidden">Previous</span>
        </button>
        <button class="embla__button embla__button--next">
            <span class="mobi-mbri mobi-mbri-arrow-next mbr-iconfont" aria-hidden="true"></span>
            <span class="sr-only visually-hidden visually-hidden">Next</span>
        </button>
    </div>
</div><?php /**PATH D:\UTM\5th Sem UTM\Software Development\SD_SEC02_G05_02\kilau-cleanix\resources\views/layouts/inc/service.blade.php ENDPATH**/ ?>